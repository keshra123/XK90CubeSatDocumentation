# XinaBox Uploader

Please visit this help page to learn more about the [XinaBox Uploader](https://xinabox.cc/pages/xinabox-uploader)

# Preferred Download Location

[<img src="https://assets.windowsphone.com/85864462-9c82-451e-9355-a3d5f874397a/English_get-it-from-MS_InvariantCulture_Default.png" height="40" style="display:inline-block;overflow:hidden;no-repeat;height:40px;">](//www.microsoft.com/store/apps/9P64Z7297WP6?cid=storebadge&amp;ocid=badge)

[<img src="https://linkmaker.itunes.apple.com/en-us/badge-lrg.svg?releaseDate=2019-03-23T00:00:00Z&kind=desktopapp&bubble=macos_apps" height="40" style="display:inline-block;overflow:hidden;no-repeat;height:40px;">](https://geo.itunes.apple.com/us/app/xinabox-uploader/id1456772276?mt=12&app=apps)

